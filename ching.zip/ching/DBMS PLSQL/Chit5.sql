--Cursors: (Implicit and Explicit Cursor). Write a PL/SQL block of code using parameterized Cursor, that will merge 
--the data available in the newly created table N_RollCall with the data available in the table O_RollCall. If the data 
--in the first table already exist in the second table then that data should be skipped. 
-- Old Roll Call Table
CREATE TABLE O_RollCall (
    Roll NUMBER PRIMARY KEY,
    Name VARCHAR2(20)
);

-- New Roll Call Table
CREATE TABLE N_RollCall (
    Roll NUMBER,
    Name VARCHAR2(20)
);
INSERT INTO O_RollCall VALUES (1, 'Arjun');
INSERT INTO O_RollCall VALUES (2, 'Rahul');

INSERT INTO N_RollCall VALUES (2, 'Rahul');  -- duplicate
INSERT INTO N_RollCall VALUES (3, 'Sneha');
INSERT INTO N_RollCall VALUES (4, 'Amit');

SELECT * from O_ROLLCALL;

SET SERVEROUTPUT ON;

DECLARE
    -- Parameterized Cursor (Explicit Cursor)
    CURSOR c_new(p_roll NUMBER) IS
        SELECT Roll, Name FROM N_RollCall WHERE Roll >= p_roll;

    v_roll N_RollCall.Roll%TYPE;
    v_name N_RollCall.Name%TYPE;

    v_count NUMBER;

BEGIN
    OPEN c_new(1);  -- parameter passed

    LOOP
        FETCH c_new INTO v_roll, v_name;
        EXIT WHEN c_new%NOTFOUND;

        -- Implicit cursor (SELECT INTO)
        SELECT COUNT(*) INTO v_count
        FROM O_RollCall
        WHERE Roll = v_roll;

        -- Control Structure
        IF v_count = 0 THEN
            INSERT INTO O_RollCall VALUES (v_roll, v_name);
            DBMS_OUTPUT.PUT_LINE('Inserted: ' || v_roll);
        ELSE
            DBMS_OUTPUT.PUT_LINE('Skipped (already exists): ' || v_roll);
        END IF;

    END LOOP;

    CLOSE c_new;

    COMMIT;

-- Exception Handling
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/
SELECT * FROM O_RollCall;