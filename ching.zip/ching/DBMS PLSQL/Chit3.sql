--Unnamed PL/SQL code block: Use of Control structure and Exception handling is mandatory. Write a PL/SQL block of code for the following requirements: -Consider table Stud(Roll, Att,Status) Write a PL/SQL block for 
--following requirement and handle the exceptions. Roll no. of student will be entered by user. Attendance of roll no. 
--entered by user will be checked in Stud table. If attendance is less than 75% then display the message “Term not 
--granted” and set the status in stud table as “D”. Otherwise display message “Term granted” and set the status in stud 
--table as “ND” . 

CREATE TABLE Stud (
    Roll NUMBER,
    Att NUMBER,
    Status VARCHAR2(2)
);
INSERT INTO Stud VALUES (1, 80, NULL);
INSERT INTO Stud VALUES (2, 60, NULL);
INSERT INTO Stud VALUES (3, 75, NULL);

COMMIT;
SELECT * FROM Stud;

SET SERVEROUTPUT ON;

DECLARE
    v_roll Stud.Roll%TYPE := &rollno;
    v_att  Stud.Att%TYPE;

BEGIN
    -- Fetch attendance
    SELECT Att
    INTO v_att
    FROM Stud
    WHERE Roll = v_roll;

    -- Control Structure
    IF v_att < 75 THEN
        UPDATE Stud
        SET Status = 'D'
        WHERE Roll = v_roll;

        DBMS_OUTPUT.PUT_LINE('Term not granted');

    ELSE
        UPDATE Stud
        SET Status = 'ND'
        WHERE Roll = v_roll;

        DBMS_OUTPUT.PUT_LINE('Term granted');
    END IF;

    COMMIT;

-- Exception Handling
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Student not found');

    WHEN TOO_MANY_ROWS THEN
        DBMS_OUTPUT.PUT_LINE('Duplicate records found');

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/
SELECT * from Stud where Roll=2;