-- Input table
CREATE TABLE Stud_Marks1 (
    Roll NUMBER,
    Name VARCHAR2(20),
    Total_Marks NUMBER
);

-- Result table
CREATE TABLE Result1 (
    Roll NUMBER,
    Name VARCHAR2(20),
    Class VARCHAR2(30)
);
INSERT INTO Stud_Marks1 VALUES (1, 'Arjun', 1200);
INSERT INTO Stud_Marks1 VALUES (2, 'Rahul', 950);
INSERT INTO Stud_Marks1 VALUES (3, 'Sneha', 850);
INSERT INTO Stud_Marks1 VALUES (4, 'Amit', 700);

COMMIT;

SELECT * FROM Stud_Marks1;

CREATE OR REPLACE FUNCTION func_Grade(
    p_marks IN NUMBER
)
RETURN VARCHAR2
IS
    v_class VARCHAR2(30);
BEGIN
    -- Control Structure
    IF p_marks BETWEEN 990 AND 1500 THEN
        v_class := 'Distinction';

    ELSIF p_marks BETWEEN 900 AND 989 THEN
        v_class := 'First Class';

    ELSIF p_marks BETWEEN 825 AND 899 THEN
        v_class := 'Higher Second Class';

    ELSE
        v_class := 'Fail';
    END IF;

    RETURN v_class;

EXCEPTION
    WHEN OTHERS THEN
        RETURN 'Error';
END;
/

SET SERVEROUTPUT ON;

DECLARE
    v_name Stud_Marks1.Name%TYPE := '&name';
    v_roll Stud_Marks1.Roll%TYPE;
    v_marks Stud_Marks1.Total_Marks%TYPE;
    v_class VARCHAR2(30);

BEGIN
    -- Fetch student data
    SELECT Roll, Total_Marks
    INTO v_roll, v_marks
    FROM Stud_Marks1
    WHERE Name = v_name;

    -- Call FUNCTION
    v_class := func_Grade(v_marks);

    -- Insert into Result table
    INSERT INTO Result1 VALUES (v_roll, v_name, v_class);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Result generated for ' || v_name);
    DBMS_OUTPUT.PUT_LINE('Class: ' || v_class);

-- Exception Handling
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Student not found');

    WHEN TOO_MANY_ROWS THEN
        DBMS_OUTPUT.PUT_LINE('Duplicate names found');

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/

SELECT * from RESULT1;