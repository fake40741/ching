--PL/SQL Stored Procedure. 
--Write a Stored Procedure namely proc_Grade for the categorization of student. If marks scored by students in 
--examination is <=1500 and marks>=990 then student will be placed in distinction category if marks scored are 
--between 989 and900 category is first class, if marks 899 and 825 category is Higher Second Class Write a PL/SQL 
--block for using procedure created with above requirement. Stud_Marks(name, total_marks) Result(Roll,Name, 
--Class).
-- Input table
CREATE TABLE Stud_Marks (
    Roll NUMBER,
    Name VARCHAR2(20),
    Total_Marks NUMBER
);

-- Result table
CREATE TABLE Result (
    Roll NUMBER,
    Name VARCHAR2(20),
    Class VARCHAR2(30)
);
INSERT INTO Stud_Marks VALUES (1, 'Arjun', 1200);
INSERT INTO Stud_Marks VALUES (2, 'Rahul', 950);
INSERT INTO Stud_Marks VALUES (3, 'Sneha', 850);
INSERT INTO Stud_Marks VALUES (4, 'Amit', 700);

COMMIT;
SELECT * FROM Stud_Marks;

CREATE OR REPLACE PROCEDURE proc_Grade(
    p_roll IN NUMBER,
    p_name IN VARCHAR2,
    p_marks IN NUMBER
)
IS
    v_class VARCHAR2(30);
BEGIN
    IF p_marks BETWEEN 990 AND 1500 THEN
        v_class := 'Distinction';

    ELSIF p_marks BETWEEN 900 AND 989 THEN
        v_class := 'First Class';

    ELSIF p_marks BETWEEN 825 AND 899 THEN
        v_class := 'Higher Second Class';

    ELSE
        v_class := 'Fail';
    END IF;

    INSERT INTO Result VALUES (p_roll, p_name, v_class);

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/

SET SERVEROUTPUT ON;

DECLARE
    v_name Stud_Marks.Name%TYPE := '&name';
    v_roll Stud_Marks.Roll%TYPE;
    v_marks Stud_Marks.Total_Marks%TYPE;

BEGIN
    -- Fetch data based on name
    SELECT Roll, Total_Marks
    INTO v_roll, v_marks
    FROM Stud_Marks
    WHERE Name = v_name;

    -- Call procedure
    proc_Grade(v_roll, v_name, v_marks);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Result generated for ' || v_name);

-- Exception Handling
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Student not found');

    WHEN TOO_MANY_ROWS THEN
        DBMS_OUTPUT.PUT_LINE('Duplicate names found');

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/

SELECT * from Result;