--Unnamed PL/SQL code block: Use of Control structure and Exception handling is mandatory. 
--Write a PL/SQL block of code for the following requirements:- 
--Schema: 
--1. Borrower(Rollin, Name, DateofIssue, NameofBook, Status) 
--2. Fine(Roll_no,Date,Amt)
-- Borrower Table
CREATE TABLE Borrower (
    Rollin NUMBER,
    Name VARCHAR2(20),
    DateofIssue DATE,
    NameofBook VARCHAR2(30),
    Status CHAR(1)
);

-- Fine Table
CREATE TABLE Fine (
    Roll_no NUMBER,
    Date1 DATE,
    Amt NUMBER
);

INSERT INTO Borrower VALUES (1, 'Arjun', SYSDATE-20, 'DBMS', 'I');
INSERT INTO Borrower VALUES (2, 'Rahul', SYSDATE-40, 'CN', 'I');
INSERT INTO Borrower VALUES (3, 'Sneha', SYSDATE-10, 'OS', 'I');

COMMIT;
SELECT * from BORROWER;

SET SERVEROUTPUT ON;

DECLARE
    v_rollno Borrower.Rollin%TYPE := &rollno;
    v_book   Borrower.NameofBook%TYPE := '&book';
    v_days   NUMBER;
    v_fine   NUMBER := 0;

BEGIN
    -- Get number of days (only issued book)
    SELECT ROUND(SYSDATE - DateofIssue)
    INTO v_days
    FROM Borrower
    WHERE Rollin = v_rollno
      AND NameofBook = v_book
      AND Status = 'I';

    DBMS_OUTPUT.PUT_LINE('Days = ' || v_days);

    -- Control Structure
    IF v_days > 30 THEN
        v_fine := v_days * 50;
    ELSIF v_days >= 15 THEN
        v_fine := v_days * 5;
    ELSE
        v_fine := 0;
    END IF;

    DBMS_OUTPUT.PUT_LINE('Fine = ' || v_fine);

    -- Insert into Fine table if applicable
    IF v_fine > 0 THEN
        INSERT INTO Fine (Roll_no, Date1, Amt)
        VALUES (v_rollno, SYSDATE, v_fine);

        DBMS_OUTPUT.PUT_LINE('Fine inserted');
    END IF;

    -- Update status from I → R
    UPDATE Borrower
    SET Status = 'R'
    WHERE Rollin = v_rollno
      AND NameofBook = v_book;

    COMMIT;

-- Exception Handling
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No matching record found');

    WHEN TOO_MANY_ROWS THEN
        DBMS_OUTPUT.PUT_LINE('Duplicate records found');

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
SELECT * from FINE;