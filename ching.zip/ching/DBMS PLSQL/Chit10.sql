CREATE TABLE Library_Audit (
    book_id NUMBER,
    book_name VARCHAR2(50),
    action VARCHAR2(10),
    action_date DATE
);
CREATE TABLE Library (
    book_id NUMBER PRIMARY KEY,
    book_name VARCHAR2(50),
    author VARCHAR2(50),
    price NUMBER
);
INSERT INTO Library VALUES (101, 'DBMS', 'Korth', 500);
INSERT INTO Library VALUES (102, 'OS', 'Galvin', 600);
INSERT INTO Library VALUES (103, 'CN', 'Tanenbaum', 550);

SELECT * FROM Library;

CREATE OR REPLACE TRIGGER trg_library_audit
BEFORE UPDATE OR DELETE ON Library
FOR EACH ROW
BEGIN
    -- For UPDATE operation
    IF UPDATING THEN
        INSERT INTO Library_Audit
        VALUES (:OLD.book_id, :OLD.book_name, 'UPDATE', SYSDATE);

    -- For DELETE operation
    ELSIF DELETING THEN
        INSERT INTO Library_Audit
        VALUES (:OLD.book_id, :OLD.book_name, 'DELETE', SYSDATE);
    END IF;
END;
/
DELETE FROM Library WHERE book_id = 101;

SELECT * FROM LIBRARY_AUDIT;

DELETE FROM Library WHERE book_id = 102;

SELECT * FROM LIBRARY_AUDIT;